﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Kutuphane_Otomasyonu
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form3_Load(object sender, EventArgs e)
        {
            // TODO: Bu kod satırı 'kutuphane_otomasyonuDataSet.Ogrenci' tablosuna veri yükler.
            // Bunu gerektiği şekilde taşıyabilir, veya kaldırabilirsiniz.
           this.ogrenciTableAdapter.Fill(this.kutuphane_otomasyonuDataSet.Ogrenci);

        }
        SqlConnection bag = new SqlConnection("Data Source=DESKTOP-JE18VQ4;Initial Catalog=kutuphane_otomasyonu;Integrated Security=True");
        private void button6_Click(object sender, EventArgs e)
        {
            SqlDataAdapter adr = new SqlDataAdapter("Select * from Ogrenci",bag);
            DataSet ds = new DataSet();
            adr.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
         
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox2.Text==null)
            {
                MessageBox.Show("TC boş bırakılamaz.");
            }
            else
            {
                bag.Open();
                SqlCommand ekle = new SqlCommand("insert into Ogrenci (Tc,Ad_Soyad,Ogrenci_No,Yas,Cinsiyet,Telefon,Adres,Email) values ('" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "','" + comboBox1.Text + "','" + textBox6.Text + "','" + textBox7.Text + "','" + textBox8.Text + "')", bag);
                ekle.ExecuteNonQuery();
                bag.Close();

                SqlDataAdapter adr = new SqlDataAdapter("Select * from Ogrenci", bag);
                DataSet ds = new DataSet();
                adr.Fill(ds);
                dataGridView1.DataSource = ds.Tables[0];
                MessageBox.Show("Ekleme İşlemi Başarılı.");
                dataGridView1.Refresh();

            }
            

        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlCommand komut = new SqlCommand();
            bag.Open();
            komut.Connection = bag;
            komut.CommandText = "DELETE from Ogrenci where Tc='" + dataGridView1.CurrentRow.Cells[0].Value.ToString() + "'";
            komut.ExecuteNonQuery();
            bag.Close();

            SqlDataAdapter adr = new SqlDataAdapter("Select * from Ogrenci", bag);
            DataSet ds = new DataSet();
            adr.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            MessageBox.Show("Silme İşlemi Başarılı.");



            /*int selectedIndex = dataGridView1.CurrentCell.RowIndex;
            if (selectedIndex > -1)
            {
                dataGridView1.Rows.RemoveAt(selectedIndex);
                dataGridView1.Refresh();
            }*/



            /* bag.Open();
             SqlCommand cmd = new SqlCommand("Delete from Ogrenci where Ogrenci_No='" + textBox4.Text + "'",bag);
             cmd.ExecuteNonQuery();
             bag.Close();

             SqlDataAdapter adr = new SqlDataAdapter("Select * from Ogrenci", bag);
             DataSet ds = new DataSet();
             adr.Fill(ds);
             dataGridView1.DataSource = ds.Tables[0];*/
        }

        private void button2_Click(object sender, EventArgs e)
        {

            SqlCommand cmd = new SqlCommand();
            bag.Open();
            cmd.Connection = bag;
            cmd.CommandText = "UPDATE Ogrenci set Tc='" + textBox2.Text + "',Ad_Soyad='" + textBox3.Text + "',Ogrenci_No='" + textBox4.Text + "',Yas='" + textBox5.Text + "',Cinsiyet='" + comboBox1.Text + "',Telefon='" + textBox6.Text + "',Adres='" + textBox7.Text + "',Email='" + textBox8.Text + "' where Tc='" + textBox2.Text + "'";
            cmd.ExecuteNonQuery();
            bag.Close();

            SqlDataAdapter adr = new SqlDataAdapter("Select * from Ogrenci", bag);
            DataSet ds = new DataSet();
            adr.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            MessageBox.Show("Güncelleme İşlemi Başarılı.");
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int secilen = dataGridView1.SelectedCells[0].RowIndex;

            string Tc = dataGridView1.Rows[secilen].Cells[0].Value.ToString();
            string Ad_Soyad = dataGridView1.Rows[secilen].Cells[1].Value.ToString();
            string Ogrenci_No = dataGridView1.Rows[secilen].Cells[2].Value.ToString();
            string Yas = dataGridView1.Rows[secilen].Cells[3].Value.ToString();
            string Cinsiyet = dataGridView1.Rows[secilen].Cells[4].Value.ToString();
            string Telefon = dataGridView1.Rows[secilen].Cells[5].Value.ToString();
            string Adres = dataGridView1.Rows[secilen].Cells[6].Value.ToString();
            string Email = dataGridView1.Rows[secilen].Cells[7].Value.ToString();

            textBox2.Text = Tc;
            textBox3.Text = Ad_Soyad;
            textBox4.Text = Ogrenci_No;
            textBox5.Text = Yas;
            comboBox1.Text = Cinsiyet;
            textBox6.Text = Telefon;
            textBox7.Text = Adres;
            textBox8.Text = Email;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form2 F2 = new Form2();
            F2.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            
            bag.Open();
            SqlCommand komut = new SqlCommand("Select * from Ogrenci where Ogrenci_No like '%" + textBox1.Text + "%'", bag);
            SqlDataAdapter dr = new SqlDataAdapter(komut);
            DataSet ds = new DataSet();
            dr.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            bag.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            SqlCommand komut = new SqlCommand("Select * from Ogrenci where Ogrenci_No like '%" + textBox1.Text + "%'", bag);
            SqlDataAdapter dr = new SqlDataAdapter(komut);
            DataSet ds = new DataSet();
            dr.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            DataView dv = ds.Tables[0].DefaultView;
            dv.RowFilter = "Ogrenci_No Like '" + textBox1.Text + "%'";
            //dv.RowFilter = string.Format("Ad LIKE '{0}%'", textBox5.Text);
            dataGridView1.DataSource = dv;
        }
    }
}
