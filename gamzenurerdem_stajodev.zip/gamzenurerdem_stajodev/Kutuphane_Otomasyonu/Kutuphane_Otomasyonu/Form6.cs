﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kutuphane_Otomasyonu
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        SqlConnection bag = new SqlConnection("Data Source=DESKTOP-JE18VQ4;Initial Catalog=kutuphane_otomasyonu;Integrated Security=True");

        private void Form6_Load(object sender, EventArgs e)
        {
            // TODO: Bu kod satırı 'kutuphane_otomasyonuDataSet3.Emanet_Kitaplar' tablosuna veri yükler. Bunu gerektiği şekilde taşıyabilir, veya kaldırabilirsiniz.
            this.emanet_KitaplarTableAdapter.Fill(this.kutuphane_otomasyonuDataSet3.Emanet_Kitaplar);

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            SqlCommand komut = new SqlCommand("Select * from Emanet_Kitaplar where Tc like '%" + textBox1.Text + "%'", bag);
            SqlDataAdapter dr = new SqlDataAdapter(komut);
            DataSet ds = new DataSet();
            dr.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            DataView dv = ds.Tables[0].DefaultView;
            dv.RowFilter = "Tc Like '" + textBox1.Text + "%'";
            
            dataGridView1.DataSource = dv;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("Select * from Emanet_Kitaplar where Barkod_No like '%" + textBox2.Text + "%'", bag);
            SqlDataAdapter dr = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            dr.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            DataView dv = ds.Tables[0].DefaultView;
            dv.RowFilter = "Barkod_No Like '" + textBox2.Text + "%'";

            dataGridView1.DataSource = dv;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bag.Open();
            SqlCommand iade = new SqlCommand("Delete from Emanet_Kitaplar where Tc=@Tc and Barkod_No=@Barkod_No", bag);
            iade.Parameters.AddWithValue("@Tc", dataGridView1.CurrentRow.Cells[0].Value.ToString());
            iade.Parameters.AddWithValue("@Barkod_No", dataGridView1.CurrentRow.Cells[4].Value.ToString());
            iade.ExecuteNonQuery();
            bag.Close();


            SqlDataAdapter adr = new SqlDataAdapter("Select * from Emanet_Kitaplar", bag);
            DataSet ds = new DataSet();
            adr.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];

            MessageBox.Show("Kitap/Kitaplar İade Edildi");


            
        }
    }
}
