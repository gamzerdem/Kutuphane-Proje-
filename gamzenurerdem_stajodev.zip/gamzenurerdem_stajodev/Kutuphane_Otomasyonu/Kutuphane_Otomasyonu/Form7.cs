﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Kutuphane_Otomasyonu
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }

        SqlConnection bag = new SqlConnection("Data Source=DESKTOP-JE18VQ4;Initial Catalog=kutuphane_otomasyonu;Integrated Security=True");

        private void Form7_Load(object sender, EventArgs e)
        {
            // TODO: Bu kod satırı 'kutuphane_otomasyonuDataSet4.Emanet_Kitaplar' tablosuna veri yükler. Bunu gerektiği şekilde taşıyabilir, veya kaldırabilirsiniz.
            this.emanet_KitaplarTableAdapter.Fill(this.kutuphane_otomasyonuDataSet4.Emanet_Kitaplar);

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(comboBox1.SelectedIndex==0)
            {
                bag.Open();
                SqlDataAdapter adr = new SqlDataAdapter("Select * from Emanet_Kitaplar", bag);
                DataSet ds = new DataSet();
                adr.Fill(ds);
                dataGridView1.DataSource = ds.Tables[0];
                bag.Close();
            }
            else if(comboBox1.SelectedIndex==1)
            {
                bag.Open();
                SqlDataAdapter adtr = new SqlDataAdapter("select * from Emanet_Kitaplar where '" + DateTime.Now.ToShortDateString() + "' > İade_Tarihi", bag);
                DataSet ds = new DataSet();
                adtr.Fill(ds);
                dataGridView1.DataSource = ds.Tables[0];
                bag.Close();

            }
            else
            {
                bag.Open();
                SqlDataAdapter adtr = new SqlDataAdapter("select * from Emanet_Kitaplar where '" + DateTime.Now.ToShortDateString() + "' <= İade_Tarihi", bag);
                DataSet ds = new DataSet();
                adtr.Fill(ds);
                dataGridView1.DataSource = ds.Tables[0];
                bag.Close();
            }
        }
    }
}
