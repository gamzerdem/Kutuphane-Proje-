﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Kutuphane_Otomasyonu
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }
        SqlConnection bag = new SqlConnection("Data Source=DESKTOP-JE18VQ4;Initial Catalog=kutuphane_otomasyonu;Integrated Security=True");

        private void Form8_Load(object sender, EventArgs e)
        {
            bag.Open();
            SqlCommand cmd = new SqlCommand("select Ad_Soyad,Okunan_Kitap_Sayisi from Grafik", bag);
            SqlDataReader read =cmd.ExecuteReader();
            while(read.Read())
            {
                chart1.Series["Okunan Kitap Sayısı"].Points.AddXY(read["Ad_Soyad"].ToString(), read["Okunan_Kitap_Sayisi"].ToString());

            }
            bag.Close();


        }
    }
}
