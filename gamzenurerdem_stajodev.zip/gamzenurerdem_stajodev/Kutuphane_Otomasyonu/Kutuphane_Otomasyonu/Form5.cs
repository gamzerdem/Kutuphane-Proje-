﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Kutuphane_Otomasyonu
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        SqlConnection bag = new SqlConnection("Data Source=DESKTOP-JE18VQ4;Initial Catalog=kutuphane_otomasyonu;Integrated Security=True");

        private void Form5_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
            /*dataGridView1.Rows.Clear();
            dataGridView1.Refresh();*/
            // TODO: Bu kod satırı 'kutuphane_otomasyonuDataSet2.Sepet' tablosuna veri yükler. Bunu gerektiği şekilde taşıyabilir, veya kaldırabilirsiniz.
            this.sepetTableAdapter.Fill(this.kutuphane_otomasyonuDataSet2.Sepet);
            int sum = 0;
            for (int i = 0; i < dataGridView1.Rows.Count; ++i)
            {
                sum += Convert.ToInt32(dataGridView1.Rows[i].Cells[5].Value);
            }

            label2.Text = sum.ToString();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            bag.Open();
            SqlCommand ekle = new SqlCommand("insert into Sepet (Barkod_No,Kitap_Adi,Yazar,Yayinevi,Sayfa_Sayisi,Kitap_Sayisi,Teslim_Tarihi,İade_Tarihi) values ('"+ textBox5.Text + "','" + textBox6.Text + "','" + textBox7.Text + "','" + textBox8.Text + "','" + textBox9.Text + "'," + textBox10.Text + ",'" + dateTimePicker1.Text + "','" + dateTimePicker2.Text + "')", bag);
            ekle.ExecuteNonQuery();
            bag.Close();

            SqlDataAdapter adr = new SqlDataAdapter("Select * from Sepet", bag);
            DataSet ds = new DataSet();
            adr.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            MessageBox.Show("Ekleme İşlemi Başarılı.");
            dataGridView1.Refresh();

            int sum = 0;
            for (int i = 0; i < dataGridView1.Rows.Count; ++i)
            {
                sum += Convert.ToInt32(dataGridView1.Rows[i].Cells[5].Value);
            }

            label2.Text =sum.ToString();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            bag.Open();
            SqlCommand komut = new SqlCommand("select * from Kitap where Barkod_no like '" + textBox5.Text + "'", bag);
            SqlDataReader read = komut.ExecuteReader();
            while(read.Read())
            {
                textBox6.Text = read["Kitap_Adi"].ToString();
                textBox7.Text = read["Yazar_Adi"].ToString();
                textBox8.Text = read["Yayinevi"].ToString();
                textBox9.Text = read["Sayfa_Sayisi"].ToString();
               
            }
            bag.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            bag.Open();
            SqlCommand cmd = new SqlCommand("select * from Ogrenci where Tc like '" + textBox1.Text + "'", bag);
          SqlDataReader read = cmd.ExecuteReader();
            while (read.Read())
            {
                textBox2.Text = read["Ad_Soyad"].ToString();
                textBox3.Text = read["Yas"].ToString();
                textBox4.Text = read["Telefon"].ToString();
                
            }
            bag.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SqlCommand komut = new SqlCommand();
            bag.Open();
            komut.Connection = bag;
            komut.CommandText = "DELETE from Sepet where Barkod_No='" + dataGridView1.CurrentRow.Cells[0].Value.ToString() + "'";
            komut.ExecuteNonQuery();
            bag.Close();

            SqlDataAdapter adr = new SqlDataAdapter("Select * from Sepet", bag);
            DataSet ds = new DataSet();
            adr.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            MessageBox.Show("Silme İşlemi Başarılı.");


            int sum = 0;
            for (int i = 0; i < dataGridView1.Rows.Count; ++i)
            {
                sum += Convert.ToInt32(dataGridView1.Rows[i].Cells[5].Value);
            }

            label2.Text = sum.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(label2.Text!="0")
            {
                if(int.Parse(label2.Text)<=3)
                {
                    if(textBox1.Text!="" && textBox2.Text!="" && textBox3.Text!="" && textBox4.Text!="")
                    {

                        for(int i = 0; i < dataGridView1.Rows.Count-1; i++)
                        {
                            bag.Open();
                            SqlCommand teslimet = new SqlCommand("insert into Emanet_Kitaplar (Tc,Ad_Soyad,Yas,Telefon,Barkod_No,Kitap_Adi,Yazar,Yayinevi,Sayfa_Sayisi,Kitap_Sayisi,Teslim_Tarihi,İade_Tarihi) values (@Tc,@Ad_Soyad,@Yas,@Telefon,@Barkod_No,@Kitap_Adi,@Yazar,@Yayinevi,@Sayfa_Sayisi,@Kitap_Sayisi,@Teslim_Tarihi,@İade_Tarihi)", bag);
                            teslimet.Parameters.AddWithValue("@Tc", textBox1.Text);
                            teslimet.Parameters.AddWithValue("@Ad_Soyad", textBox2.Text);
                            teslimet.Parameters.AddWithValue("@Yas", textBox3.Text);
                            teslimet.Parameters.AddWithValue("@Telefon", textBox4.Text);
                            teslimet.Parameters.AddWithValue("@Barkod_No", dataGridView1.Rows[i].Cells[0].Value.ToString());
                            teslimet.Parameters.AddWithValue("@Kitap_Adi", dataGridView1.Rows[i].Cells[1].Value.ToString());
                            teslimet.Parameters.AddWithValue("@Yazar", dataGridView1.Rows[i].Cells[2].Value.ToString());
                            teslimet.Parameters.AddWithValue("@Yayinevi", dataGridView1.Rows[i].Cells[3].Value.ToString());
                            teslimet.Parameters.AddWithValue("@Sayfa_Sayisi", dataGridView1.Rows[i].Cells[4].Value.ToString());
                            teslimet.Parameters.AddWithValue("@Kitap_Sayisi", int.Parse(dataGridView1.Rows[i].Cells[5].Value.ToString()));
                            teslimet.Parameters.AddWithValue("@Teslim_Tarihi", dataGridView1.Rows[i].Cells[6].Value.ToString());
                            teslimet.Parameters.AddWithValue("@İade_Tarihi", dataGridView1.Rows[i].Cells[7].Value.ToString());
                           
                            teslimet.ExecuteNonQuery();
                            bag.Close();

                            

                            bag.Open();
                            SqlCommand cmd = new SqlCommand("delete from Sepet",bag);
                            cmd.ExecuteNonQuery();
                            bag.Close();

                            MessageBox.Show("Emanet Etme İşlemi Başarılı.");
                            dataGridView1.DataSource = null;






                            /*+ dataGridView1.Rows[i].Cells[0].Value + "','"
                            + dataGridView1.Rows[i].Cells[1].Value + "','"
                            + dataGridView1.Rows[i].Cells[2].Value + "','"
                            + dataGridView1.Rows[i].Cells["Yayinevi"].Value + "','"
                            + dataGridView1.Rows[i].Cells["Sayfa_Sayisi"].Value + "',"
                            + dataGridView1.Rows[i].Cells["Kitap_Sayisi"].Value + ",'"
                            + dataGridView1.Rows[i].Cells["Teslim_Tarihi"].Value + "','"
                            + dataGridView1.Rows[i].Cells["İade_Tarihi"].Value + "')", bag);








                        teslimet.Parameters.AddWithValue("@Tc", textBox1.Text);
                        teslimet.Parameters.AddWithValue("@Ad_Soyad", textBox2.Text);
                        teslimet.Parameters.AddWithValue("@Yas", textBox3.Text);
                        teslimet.Parameters.AddWithValue("@Telefon", textBox4.Text);
                        teslimet.Parameters.AddWithValue("@Barkod_No", dataGridView1.Rows[i].Cells["Barkod_No"].Value.ToString());
                        teslimet.Parameters.AddWithValue("@Kitap_Adi", dataGridView1.Rows[i].Cells["Kitap_Adi"].Value.ToString());
                        teslimet.Parameters.AddWithValue("@Yazar", dataGridView1.Rows[i].Cells["Yazar"].Value.ToString());
                        teslimet.Parameters.AddWithValue("@Yayinevi", dataGridView1.Rows[i].Cells["Yayinevi"].Value.ToString());
                        teslimet.Parameters.AddWithValue("@Sayfa_Sayisi", dataGridView1.Rows[i].Cells["Sayfa_Sayisi"].Value.ToString());
                        teslimet.Parameters.AddWithValue("@Kitap_Sayisi", int.Parse(dataGridView1.Rows[i].Cells["Kitap_Sayisi"].Value.ToString()));
                        teslimet.Parameters.AddWithValue("@Teslim_Tarihi", dataGridView1.Rows[i].Cells["Teslim_Tarihi"].Value.ToString());
                        teslimet.Parameters.AddWithValue("@İade_Tarihi", dataGridView1.Rows[i].Cells["İade_Tarihi"].Value.ToString());
                        */


                        }
                        int sum = 0;
                        for (int i = 0; i < dataGridView1.Rows.Count; ++i)
                        {
                            sum += Convert.ToInt32(dataGridView1.Rows[i].Cells[5].Value);
                        }

                        label2.Text = sum.ToString();
                    }
                    else
                    {
                        MessageBox.Show("Lütfen Öğrenci Bilgilerini Doldurunuz.");
                    }
                }
                else
                {
                    MessageBox.Show("Kitap Sayısı 3 Adetten Fazla Olamaz.");
                }
            }
            else
            {
                MessageBox.Show("Lütfen Kitap Seçimi Yapınız.");
            }
        }
    }
}
