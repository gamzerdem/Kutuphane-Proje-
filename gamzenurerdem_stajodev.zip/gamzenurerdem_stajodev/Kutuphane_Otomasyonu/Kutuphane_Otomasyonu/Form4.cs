﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Kutuphane_Otomasyonu
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }
        SqlConnection bag = new SqlConnection("Data Source=DESKTOP-JE18VQ4;Initial Catalog=kutuphane_otomasyonu;Integrated Security=True");

        private void Form4_Load(object sender, EventArgs e)
        {
            // TODO: Bu kod satırı 'kutuphane_otomasyonuDataSet1.Kitap' tablosuna veri yükler. Bunu gerektiği şekilde taşıyabilir, veya kaldırabilirsiniz.
            this.kitapTableAdapter.Fill(this.kutuphane_otomasyonuDataSet1.Kitap);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == null)
            {
                MessageBox.Show("Barkod No Boş Bırakılamaz.");
            }
            else
            {
                bag.Open();
                SqlCommand ekle = new SqlCommand("insert into Kitap (Barkod_no,Kitap_Adi,Yazar_Adi,Yayinevi,Sayfa_Sayisi,Kitap_Turu,Basim_Yili,Raf_No) values ('" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "','" + textBox6.Text + "','" + comboBox1.Text + "','" + textBox7.Text + "','" + textBox8.Text + "')", bag);
                ekle.ExecuteNonQuery();
                bag.Close();

                SqlDataAdapter adr = new SqlDataAdapter("Select * from Kitap", bag);
                DataSet ds = new DataSet();
                adr.Fill(ds);
                dataGridView1.DataSource = ds.Tables[0];
                MessageBox.Show("Ekleme İşlemi Başarılı.");
                dataGridView1.Refresh();

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand();
            bag.Open();
            cmd.Connection = bag;
            cmd.CommandText = "UPDATE Kitap set Barkod_no='" + textBox2.Text + "',Kitap_Adi='" + textBox3.Text + "',Yazar_Adi='" + textBox4.Text + "',Yayinevi='" + textBox5.Text + "',Sayfa_Sayisi='" + textBox6.Text + "',Kitap_Turu='" + comboBox1.Text + "',Basim_Yili='" + textBox7.Text + "',Raf_No='" + textBox8.Text + "' where Barkod_no='" + textBox2.Text + "'";
            cmd.ExecuteNonQuery();
            bag.Close();

            SqlDataAdapter adr = new SqlDataAdapter("Select * from Kitap", bag);
            DataSet ds = new DataSet();
            adr.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            MessageBox.Show("Güncelleme İşlemi Başarılı.");
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int secilen = dataGridView1.SelectedCells[0].RowIndex;

            string Barkod_no = dataGridView1.Rows[secilen].Cells[0].Value.ToString();
            string Kitap_Adi = dataGridView1.Rows[secilen].Cells[1].Value.ToString();
            string Yazar_Adi = dataGridView1.Rows[secilen].Cells[2].Value.ToString();
            string Yayinevi = dataGridView1.Rows[secilen].Cells[3].Value.ToString();
            string Sayfa_Sayisi = dataGridView1.Rows[secilen].Cells[4].Value.ToString();
            string Kitap_Turu = dataGridView1.Rows[secilen].Cells[5].Value.ToString();
            string Basim_Yili = dataGridView1.Rows[secilen].Cells[6].Value.ToString();
            string Raf_No = dataGridView1.Rows[secilen].Cells[7].Value.ToString();

            textBox2.Text = Barkod_no;
            textBox3.Text = Kitap_Adi;
            textBox4.Text = Yazar_Adi;
            textBox5.Text = Yayinevi;
            textBox6.Text = Sayfa_Sayisi;
            comboBox1.Text = Kitap_Turu;
            textBox7.Text = Basim_Yili;
            textBox8.Text = Raf_No;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlCommand komut = new SqlCommand();
            bag.Open();
            komut.Connection = bag;
            komut.CommandText = "DELETE from Kitap where Barkod_no='" + dataGridView1.CurrentRow.Cells[0].Value.ToString() + "'";
            komut.ExecuteNonQuery();
            bag.Close();

            SqlDataAdapter adr = new SqlDataAdapter("Select * from Kitap", bag);
            DataSet ds = new DataSet();
            adr.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            MessageBox.Show("Silme İşlemi Başarılı.");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form2 F2 = new Form2();
            F2.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            SqlDataAdapter adr = new SqlDataAdapter("Select * from Kitap", bag);
            DataSet ds = new DataSet();
            adr.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void button6_Click(object sender, EventArgs e)
        {
            
            bag.Open();
            SqlCommand komut = new SqlCommand("Select * from Kitap where Kitap_Adi like '%" + textBox1.Text + "%'", bag);
            SqlDataAdapter dr = new SqlDataAdapter(komut);
            DataSet ds = new DataSet();
            dr.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            bag.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            SqlCommand komut = new SqlCommand("Select * from Kitap where Kitap_Adi like '%" + textBox1.Text + "%'", bag);
            SqlDataAdapter dr = new SqlDataAdapter(komut);
            DataSet ds = new DataSet();
            dr.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            DataView dv = ds.Tables[0].DefaultView;
            dv.RowFilter = "Kitap_Adi Like '" + textBox1.Text + "%'";
            //dv.RowFilter = string.Format("Ad LIKE '{0}%'", textBox5.Text);
            dataGridView1.DataSource = dv;
        }
    }
}
